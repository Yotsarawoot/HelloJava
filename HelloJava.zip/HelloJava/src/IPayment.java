interface IPayment {

    public int getPayment();
    public String getName();

}
