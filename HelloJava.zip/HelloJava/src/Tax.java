public interface Tax {
    public int getTax();
}
